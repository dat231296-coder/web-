
import React, { useState } from 'react';
import { MarketingIdea } from '../types';

interface IdeaCardProps {
  idea: MarketingIdea;
}

const IdeaCard: React.FC<IdeaCardProps> = ({ idea }) => {
  const [copied, setCopied] = useState(false);

  const copyToClipboard = () => {
    const text = `${idea.content}\n\n${idea.hashtags.join(' ')}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden hover:shadow-md transition-all group">
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-3">
            <span className="text-3xl">{idea.emoji}</span>
            <div>
              <h3 className="font-bold text-slate-800">{idea.title}</h3>
              <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full uppercase tracking-wider">
                {idea.target}
              </span>
            </div>
          </div>
          <button 
            onClick={copyToClipboard}
            className={`p-2 rounded-lg transition-colors ${copied ? 'bg-green-100 text-green-600' : 'bg-slate-50 text-slate-400 group-hover:text-blue-500 hover:bg-blue-50'}`}
          >
            {copied ? (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
            ) : (
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"></path></svg>
            )}
          </button>
        </div>
        
        <p className="text-slate-600 leading-relaxed mb-4 italic">
          "{idea.content}"
        </p>
        
        <div className="flex flex-wrap gap-2">
          {idea.hashtags.map((tag, idx) => (
            <span key={idx} className="text-sm text-blue-500 font-medium">
              {tag}
            </span>
          ))}
        </div>
      </div>
      
      <div className="bg-slate-50 px-6 py-3 border-t border-slate-100 flex justify-between items-center">
        <span className="text-xs text-slate-400">Xem trước bài viết Facebook</span>
        <div className="flex space-x-1">
          <div className="w-2 h-2 rounded-full bg-slate-200"></div>
          <div className="w-2 h-2 rounded-full bg-slate-200"></div>
          <div className="w-2 h-2 rounded-full bg-slate-200"></div>
        </div>
      </div>
    </div>
  );
};

export default IdeaCard;
