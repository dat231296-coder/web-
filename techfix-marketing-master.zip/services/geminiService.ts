
import { GoogleGenAI, Type } from "@google/genai";
import { MarketingIdea } from "../types";

export const generateMarketingIdeas = async (
  audience: string, 
  tone: string, 
  context: string
): Promise<MarketingIdea[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `Bạn là một chuyên gia Marketing hàng đầu. Hãy viết 3 ý tưởng bài đăng Facebook ngắn gọn, hài hước để quảng cáo dịch vụ sửa chữa máy tính lấy liền. 
  Đối tượng: ${audience}. 
  Tông giọng: ${tone}. 
  Bối cảnh bổ sung: ${context}.
  Yêu cầu: Bài viết phải bắt trend, đánh trúng nỗi đau (pain point) của đối tượng và nhấn mạnh vào yếu tố "LẤY LIỀN".`;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            content: { type: Type.STRING },
            hashtags: { 
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            emoji: { type: Type.STRING },
            target: { type: Type.STRING }
          },
          required: ["title", "content", "hashtags", "emoji", "target"]
        }
      }
    }
  });

  try {
    return JSON.parse(response.text || "[]");
  } catch (error) {
    console.error("Failed to parse Gemini response:", error);
    return [];
  }
};
